package com.virtusa.service;

public interface CustomerService {

}
