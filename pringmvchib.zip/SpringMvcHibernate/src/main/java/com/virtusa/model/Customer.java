package com.virtusa.model;


	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.Table;
	
	@Entity
	@Table(name="Customer")
	public class Customer {
	    @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    @Column(name = "Customer_Id")
	    private Integer customerId;
	   
	    @Column(name = "Name")
	    private String name;
	    
	    @Column(name="Email")
	   private String email;
	   
	    @Column(name = "Age")
	    private Integer age;
	   
	    @Column(name = "Gender")
	    private String gender;

		public Integer getCustomerId() {
			return customerId;
		}

		public void setCustomerId(Integer customerId) {
			this.customerId = customerId;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public Integer getAge() {
			return age;
		}

		public void setAge(Integer age) {
			this.age = age;
		}

		public String getGender() {
			return gender;
		}

		public void setGender(String gender) {
			this.gender = gender;
		}

		@Override
		public String toString() {
			return "Customer [customerId=" + customerId + ", name=" + name + ", email=" + email + ", age=" + age
					+ ", gender=" + gender + "]";
		}
	    
	    
	   
	    
}
