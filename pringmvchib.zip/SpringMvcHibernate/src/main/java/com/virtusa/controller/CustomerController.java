package com.virtusa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.virtusa.model.Customer;
import com.virtusa.service.CustomerService;

@Controller
public class CustomerController {
//	  @Autowired
//	    private CustomerService customerService;
	 
	    @RequestMapping(value = "/customerRegistration", method = RequestMethod.GET)
	    public String displyAllCustomers(Model model) {
	        model.addAttribute("customer", new Customer());
//	        model.addAttribute("employeeList", employeeService.listEmployees());
	        return "AddCustomer";
	    }
	 
//	    // Same method For both Add and Update Employee
//	    @RequestMapping(value = "/employee/add", method = RequestMethod.POST)
//	    public String addemployee(@ModelAttribute("employee") Employee employee) {
//	 
//	        if (employee.getEmployeeId()==null || employee.getEmployeeId() == 0) {
//	            // new employee, add it
//	            employeeService.addEmployee(employee);
//	        } else {
//	            // existing employee, call update
//	            employeeService.updateEmployee(employee);
//	        }
//	 
//	        return "redirect:/employees";
//	 
//	    }
//	 
//	    @RequestMapping("/employee/remove/{id}")
//	    public String removeemployee(@PathVariable("id") int id) {
//	 
//	        employeeService.removeEmployee(id);
//	        return "redirect:/employees";
//	    }
//	 
//	    @RequestMapping("/employee/edit/{id}")
//	    public String editemployee(@PathVariable("id") int id, Model model) {
//	        model.addAttribute("employee", employeeService.getEmployeeById(id));
//	        model.addAttribute("employeeList", employeeService.listEmployees());
//	        return "employee";
//	    }
//	}
}
